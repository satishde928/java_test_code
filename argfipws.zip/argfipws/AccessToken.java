/*    */ package argafipws;
/*    */ 
/*    */ public class AccessToken {
/*    */   private String token;
/*    */   
/*    */   private String sign;
/*    */   
/*    */   private String expiryDate;
/*    */   
/*    */   public AccessToken(String token, String sign, String expiryDate) {
/* 12 */     this.token = token;
/* 13 */     this.sign = sign;
/* 14 */     this.expiryDate = expiryDate;
/*    */   }
/*    */   
/*    */   public String getToken() {
/* 19 */     return this.token;
/*    */   }
/*    */   
/*    */   public void setToken(String token) {
/* 24 */     this.token = token;
/*    */   }
/*    */   
/*    */   public String getSign() {
/* 29 */     return this.sign;
/*    */   }
/*    */   
/*    */   public void setSign(String sign) {
/* 34 */     this.sign = sign;
/*    */   }
/*    */   
/*    */   public String getExpiryDate() {
/* 39 */     return this.expiryDate;
/*    */   }
/*    */   
/*    */   public void setExpiryDate(String expiryDate) {
/* 44 */     this.expiryDate = expiryDate;
/*    */   }
/*    */ }


/* Location:              C:\Users\ap255125\Downloads\ArgAFIPWS.jar!\argafipws\AccessToken.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */