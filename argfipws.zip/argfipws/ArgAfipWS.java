/*     */ package argafipws;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.PropertyConfigurator;
/*     */ 
/*     */ public class ArgAfipWS {
/*  18 */   static final Logger logger = Logger.getLogger(ArgAfipWS.class);
/*     */   
/*     */   public static void main(String[] args) {
/*  23 */     String log4jConfPath = "./log4j.properties";
/*  24 */     PropertyConfigurator.configure(log4jConfPath);
/*  25 */     if (logger.isInfoEnabled())
/*  26 */       logger.info("This is info1 : "); 
/*  29 */     Params.LoadParams("./parameters.properties");
/*  32 */     if ("FILE".equals(Params.getConnectionType())) {
/*  34 */       ArrayList<ObjectWS> ListaObjectWS = FileLoadArray.Get_Array_List();
/*  36 */       CallAfipWebService(ListaObjectWS);
/*  37 */       FileLoadArray.Write_Response_To_Xml(ListaObjectWS);
/*  42 */     } else if ("DB".equals(Params.getConnectionType())) {
/*  43 */       ArrayList<ObjectWS> ListaObjectWS = DBLoadArray.Get_Array_List();
/*  44 */       CallAfipWebService(ListaObjectWS);
/*  46 */       DBLoadArray.Write_Response_To_DB(ListaObjectWS);
/*     */       try {
/*  49 */         Params.getJDBCconn().close();
/*  50 */       } catch (SQLException e) {
/*  51 */         System.out.println("Error database " + e.getMessage());
/*  52 */         System.exit(1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void CallAfipWebService(ArrayList<ObjectWS> ListaObjectWS) {
/*  60 */     String Last_Service = "_blank";
/*  61 */     String token = null;
/*  62 */     String sign = null;
/*  63 */     String WS_Login_URL = null;
/*  65 */     ObjectLoginWS objectLogin = new ObjectLoginWS(Params.getFileName(), Params.getPassword(), Params.getSigner());
/*  66 */     if (objectLogin.getPrivateKey() == null) {
/*  68 */       System.out.println("Certificate Error.Please contact System Administrator");
/*  69 */       System.exit(1);
/*     */     } 
/*  71 */     for (ObjectWS Record : ListaObjectWS) {
/*  73 */       System.out.println("");
/*  74 */       String psService = Record.getWS_Name();
/*  77 */       if (Last_Service.compareTo(psService) != 0) {
/*  80 */         String psWS_Login_URl = Record.getWS_Login();
/*  81 */         Last_Service = psService;
/*  82 */         System.out.println("Login Service Login: " + psWS_Login_URl);
/*  83 */         System.out.println("Login Service Name: " + psService);
/*  84 */         AccessToken AccessTokenObj = LoginService.callLoginService(psWS_Login_URl, psService, objectLogin.getPrivateKey(), objectLogin.getCertificate(), objectLogin.getSignerDN());
/*  86 */         token = AccessTokenObj.getToken();
/*  87 */         sign = AccessTokenObj.getSign();
/*     */       } 
/*  89 */       System.out.println("CallWebServices ");
/*  90 */       System.out.println("     Invoice_Type:" + Record.getInvoice_Type());
/*  91 */       System.out.println("      Trx_Number:" + Record.getTrx_Number());
/*  92 */       System.out.println("      Customer_Trx_Id:" + Record.getCustomer_Trx_Id());
/*  94 */       String WebServiceTicketResponse = WebServices.CallWebServices(Record, token, sign);
/*  95 */       if (!Record.getXmlerror().booleanValue()) {
/*  97 */         String ResponseXML = WebServices.Get_Response(WebServiceTicketResponse, psService, Record.getWS_Method());
/*  99 */         System.out.println("Response: " + ResponseXML);
/* 100 */         Record.setXml_Output(ResponseXML);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ap255125\Downloads\ArgAFIPWS.jar!\argafipws\ArgAfipWS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */