/*     */ package argafipws;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class DBLoadArray {
/*     */   public static ArrayList<ObjectWS> Get_Array_List() {
/*  17 */     ArrayList<ObjectWS> ListaObjectWS = new ArrayList<ObjectWS>();
/*     */     try {
/*  22 */       Statement sqlStmt = Params.getJDBCconn().createStatement();
/*  23 */       ResultSet qresult = sqlStmt.executeQuery("SELECT * FROM " + Params.getElectronicInvoiceWSViewName());
/*  24 */       if (!qresult.isBeforeFirst()) {
/*  25 */         System.out.println("**** NO DATA FOUND ****");
/*  26 */         System.out.println("No pending Transaction to be processed.");
/*     */       } 
/*  29 */       while (qresult.next()) {
/*  30 */         System.out.println("Adding Transaction " + qresult.getString("INVOICE_TYPE") + " " + qresult.getString("TRX_NUMBER"));
/*  31 */         String Doc_Type = qresult.getString("DOCUMENT_TYPE");
/*  32 */         String Doc_Num = qresult.getString("NRO_DOC");
/*  33 */         String Doc_Pos = qresult.getString("PTOVTA");
/*  34 */         String WS_Login = qresult.getString("WS_LOGIN_URL");
/*  35 */         String WS_Metodo = qresult.getString("WS_METHOD");
/*  36 */         String WS_Name = qresult.getString("WS_SERVICE");
/*  37 */         String WS_Url = qresult.getString("WS_URL");
/*  38 */         int Customer_Trx_Id = qresult.getInt("CUSTOMER_TRX_ID");
/*  39 */         String Trx_Number = qresult.getString("TRX_NUMBER");
/*  40 */         String Invoice_Type = qresult.getString("INVOICE_TYPE");
/*  42 */         String xml_output = qresult.getString("XML_OUTPUT");
/*  43 */         String nombre_archivo = null;
/*  44 */         ObjectWS ObjectWS_Return = new ObjectWS(Doc_Type, Doc_Num, Doc_Pos, WS_Login, WS_Url, WS_Metodo, WS_Name, Invoice_Type, Trx_Number, Customer_Trx_Id, xml_output, nombre_archivo);
/*  46 */         ListaObjectWS.add(ObjectWS_Return);
/*     */       } 
/*  48 */       qresult.close();
/*  49 */     } catch (SQLException e) {
/*  51 */       System.out.println("Error database " + e.getMessage());
/*  52 */       System.exit(1);
/*     */     } 
/*  60 */     ListaObjectWS.trimToSize();
/*  64 */     return ListaObjectWS;
/*     */   }
/*     */   
/*     */   public static void Write_Response_To_DB(ArrayList<ObjectWS> ListaObjectWS) {
/*  72 */     PreparedStatement preparedStatement = null;
/*  73 */     String insertSQL = "INSERT INTO " + Params.getElectronicInvoiceWSTrxTableName() + " ( XXSBC_AR_ARFE_WS_TRX_ID" + " ,CUSTOMER_TRX_ID" + ", AFIP_RESPONSE_XML" + ", STATUS" + ", WS_URL" + ", WS_NAME" + ", WS_METHOD" + ", CREATED_BY" + ", CREATION_DATE" + ", LAST_UPDATED_BY" + ", LAST_UPDATE_DATE" + ", LAST_UPDATE_LOGIN)" + " SELECT XXSBC_AR_ARFE_WS_TRX_S.NEXTVAL" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?  FROM DUAL";
/* 102 */     for (ObjectWS Record : ListaObjectWS) {
/*     */       try {
/* 105 */         preparedStatement = Params.getJDBCconn().prepareStatement(insertSQL);
/* 106 */         preparedStatement.setInt(1, Record.getCustomer_Trx_Id());
/* 107 */         preparedStatement.setString(2, Record.getXml_Output());
/* 108 */         preparedStatement.setString(3, "PENDING");
/* 109 */         preparedStatement.setString(4, Record.getWS_Url());
/* 110 */         preparedStatement.setString(5, Record.getWS_Name());
/* 111 */         preparedStatement.setString(6, Record.getWS_Method());
/* 112 */         preparedStatement.setInt(7, -1);
/* 113 */         preparedStatement.setTimestamp(8, getCurrentTimeStamp());
/* 114 */         preparedStatement.setInt(9, -1);
/* 115 */         preparedStatement.setTimestamp(10, getCurrentTimeStamp());
/* 116 */         preparedStatement.setInt(11, -1);
/* 118 */         preparedStatement.executeUpdate();
/* 120 */         preparedStatement.close();
/* 121 */       } catch (SQLException e) {
/* 123 */         System.out.println(e.getMessage());
/* 124 */         System.exit(1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Timestamp getCurrentTimeStamp() {
/* 132 */     Date today = new Date();
/* 133 */     return new Timestamp(today.getTime());
/*     */   }
/*     */ }


/* Location:              C:\Users\ap255125\Downloads\ArgAFIPWS.jar!\argafipws\DBLoadArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */