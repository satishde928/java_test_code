/*     */ package argafipws;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileWriter;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.commons.io.comparator.NameFileComparator;
/*     */ import org.jdom.Document;
/*     */ import org.jdom.Element;
/*     */ import org.jdom.JDOMException;
/*     */ import org.jdom.input.SAXBuilder;
/*     */ 
/*     */ class FileLoadArray {
/*     */   public static ArrayList<ObjectWS> Get_Array_List() {
/*  36 */     ArrayList<ObjectWS> ListaObjectWS = new ArrayList<ObjectWS>();
/*  40 */     String requestFilesPath = Params.getRequestFilesPath();
/*  41 */     File ruta = new File(requestFilesPath);
/*  44 */     File[] archivos = ruta.listFiles(new FilenameFilter() {
/*     */           public boolean accept(File directory, String fileName) {
/*  47 */             if (fileName.endsWith(".xml"))
/*  48 */               return true; 
/*  50 */             return false;
/*     */           }
/*     */         });
/*  53 */     Arrays.sort(archivos, NameFileComparator.NAME_COMPARATOR);
/*  54 */     System.out.println("");
/*  55 */     System.out.println("Archivos a procesar");
/*     */     File[] arrayOfFile1;
/*     */     byte b;
/*  56 */     for (arrayOfFile1 = archivos, b = 0; b < arrayOfFile1.length; ) {
/*  56 */       File f = arrayOfFile1[b];
/*  58 */       System.out.println("\t" + f.getAbsolutePath());
/*  60 */       ObjectWS ObjectWS_Return = Get_Object_Array(f);
/*  61 */       ListaObjectWS.add(ObjectWS_Return);
/*     */       b++;
/*     */     } 
/*  67 */     ListaObjectWS.trimToSize();
/*  71 */     return ListaObjectWS;
/*     */   }
/*     */   
/*     */   private static ObjectWS Get_Object_Array(File xmlFile) {
/*  79 */     SAXBuilder builder = new SAXBuilder();
/*     */     try {
/*  84 */       Document document = builder.build(xmlFile);
/*  85 */       String nombre_archivo = xmlFile.getName();
/*  88 */       Element rootNode = document.getRootElement();
/*  90 */       String xml_output = rootNode.getChildTextTrim("XML_OUTPUT");
/*  93 */       List<?> list = rootNode.getChildren("XX_WS_INFO");
/*  95 */       Element tabla = (Element)list.get(0);
/*  97 */       String Doc_Type = tabla.getChildTextTrim("DOCUMENT_TYPE");
/*  98 */       String Doc_Num = tabla.getChildTextTrim("NRO_DOC");
/*  99 */       String Doc_Pos = tabla.getChildTextTrim("PTOVTA");
/* 100 */       String Invoice_Type = tabla.getChildTextTrim("INVOICE_TYPE");
/* 101 */       String Trx_Number = tabla.getChildTextTrim("TRX_NUMBER");
/* 102 */       String WS_Login = tabla.getChildTextTrim("WS_LOGIN_URL");
/* 103 */       String WS_Url = tabla.getChildTextTrim("WS_URL");
/* 104 */       String WS_Method = tabla.getChildTextTrim("WS_METHOD");
/* 105 */       String WS_Name = tabla.getChildTextTrim("WS_SERVICE");
/* 106 */       int Customer_Trx_Id = Integer.parseInt(tabla.getChildTextTrim("CUSTOMER_TRX_ID"));
/* 108 */       return new ObjectWS(Doc_Type, Doc_Num, Doc_Pos, WS_Login, WS_Url, WS_Method, WS_Name, Invoice_Type, Trx_Number, Customer_Trx_Id, xml_output, nombre_archivo);
/* 110 */     } catch (IOException io) {
/* 111 */       System.out.println(io.getMessage());
/* 112 */     } catch (JDOMException jdomex) {
/* 113 */       System.out.println(jdomex.getMessage());
/*     */     } 
/* 116 */     return null;
/*     */   }
/*     */   
/*     */   public static void Write_Response_To_Xml(ArrayList<ObjectWS> ListaObjectWS) {
/* 122 */     for (ObjectWS Record : ListaObjectWS) {
/* 124 */       String nombreArchivo = Record.getNombre_Archivo().replace("Request_", Params.getResponsePrefix());
/* 126 */       String xmlGeneral = "<XX_Main><XX_WS_INFO><WS_SERVICE>" + Record.getWS_Name() + "</WS_SERVICE>" + "<WS_METHOD>" + Record.getWS_Method() + "</WS_METHOD>" + "<WS_URL>" + Record.getWS_Url() + "</WS_URL>" + "<INVOICE_TYPE>" + Record.getInvoice_Type() + "</INVOICE_TYPE>" + "<TRX_NUMBER>" + Record.getTrx_Number() + "</TRX_NUMBER>" + "<DOCUMENT_TYPE>" + Record.getDoc_Type() + "</DOCUMENT_TYPE>" + "<NRO_DOC>" + Record.getDoc_Num() + "</NRO_DOC>" + "<PTOVTA>" + Record.getDoc_Pos() + "</PTOVTA>" + "<CUSTOMER_TRX_ID>" + Record.getCustomer_Trx_Id() + "</CUSTOMER_TRX_ID>" + "</XX_WS_INFO>" + "<XML_OUTPUT>![CDATA[" + Record.getXml_Output() + "]]</XML_OUTPUT>" + "</XX_Main>";
/* 141 */       String rutaArchivo = Params.getResponseFilesPath() + "//" + nombreArchivo;
/* 142 */       File archivo = new File(rutaArchivo);
/*     */       try {
/* 146 */         BufferedWriter bw = new BufferedWriter(new FileWriter(archivo));
/* 147 */         bw.write(xmlGeneral);
/* 148 */         bw.close();
/* 149 */         if (Params.getHistoryFilesPath().compareTo("") != 0) {
/* 151 */           DateFormat df = new SimpleDateFormat("yyyyMMdd_HHmmss");
/* 152 */           Date today = Calendar.getInstance().getTime();
/* 153 */           String reportDate = df.format(today);
/* 155 */           InputStream in = null;
/* 156 */           OutputStream out = null;
/*     */           try {
/* 158 */             File oldFile = new File(Params.getRequestFilesPath() + "//" + Record.getNombre_Archivo());
/* 159 */             File newFile = new File(Params.getHistoryFilesPath() + "//" + Record.getNombre_Archivo() + "." + reportDate);
/* 160 */             in = new FileInputStream(oldFile);
/* 161 */             out = new FileOutputStream(newFile);
/* 162 */             byte[] moveBuff = new byte[1024];
/*     */             int butesRead;
/* 164 */             while ((butesRead = in.read(moveBuff)) > 0)
/* 165 */               out.write(moveBuff, 0, butesRead); 
/* 169 */             in.close();
/* 170 */             out.close();
/* 171 */             oldFile.delete();
/* 172 */             System.out.println("File " + Params.getRequestFilesPath() + "//" + Record.getNombre_Archivo() + "  was successfully moved to " + Params.getHistoryFilesPath() + "//" + Record.getNombre_Archivo() + "." + reportDate);
/* 174 */           } catch (IOException e) {
/* 176 */             e.printStackTrace();
/*     */           } 
/*     */         } 
/* 185 */       } catch (IOException e) {
/* 187 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ap255125\Downloads\ArgAFIPWS.jar!\argafipws\FileLoadArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */