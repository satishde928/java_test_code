/*     */ package argafipws;
/*     */ 
/*     */ import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.net.URL;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.Security;
/*     */ import java.security.cert.CertStore;
/*     */ import java.security.cert.CollectionCertStoreParameters;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import javax.xml.rpc.ParameterMode;
/*     */ import org.apache.axis.client.Call;
/*     */ import org.apache.axis.client.Service;
/*     */ import org.apache.axis.encoding.Base64;
/*     */ import org.apache.axis.encoding.XMLType;
/*     */ import org.bouncycastle.cms.CMSProcessable;
/*     */ import org.bouncycastle.cms.CMSProcessableByteArray;
/*     */ import org.bouncycastle.cms.CMSSignedData;
/*     */ import org.bouncycastle.cms.CMSSignedDataGenerator;
/*     */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.io.SAXReader;
/*     */ 
/*     */ public class LoginService {
/*     */   public static AccessToken callLoginService(String endpoint, String psService, PrivateKey pKey, X509Certificate pCertificate, String pSignerDN) {
/*  41 */     String LoginTicketResponse = null;
/*  43 */     System.setProperty("http.proxyHost", "");
/*  44 */     System.setProperty("http.proxyPort", "80");
/*  47 */     String dstDN = Params.getCompanyDestination();
/*  48 */     String service = psService;
/*  50 */     Long TicketTime = Long.valueOf(3600000L);
/*  58 */     byte[] LoginTicketRequest_xml_cms = create_cms(pKey, pCertificate, pSignerDN, dstDN, service, TicketTime);
/*     */     try {
/*  63 */       LoginTicketResponse = invoke_wsaa(LoginTicketRequest_xml_cms, endpoint);
/*  65 */     } catch (Exception e) {
/*  67 */       e.printStackTrace();
/*     */     } 
/*     */     try {
/*  73 */       Reader tokenReader = new StringReader(LoginTicketResponse);
/*  74 */       Document tokenDoc = (new SAXReader(false)).read(tokenReader);
/*  76 */       String token = tokenDoc.valueOf("/loginTicketResponse/credentials/token");
/*  77 */       String sign = tokenDoc.valueOf("/loginTicketResponse/credentials/sign");
/*  78 */       String expiryDate = tokenDoc.valueOf("/loginTicketResponse/header/expirationTime");
/*  80 */       return new AccessToken(token, sign, expiryDate);
/*  82 */     } catch (Exception e) {
/*  84 */       System.out.println(e);
/*  86 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static byte[] create_cms(PrivateKey pKey, X509Certificate pCertificate, String pSignerDN, String dstDN, String service, Long TicketTime) {
/*  98 */     byte[] asn1_cms = null;
/*  99 */     CertStore cstore = null;
/*     */     try {
/* 121 */       ArrayList<X509Certificate> certList = new ArrayList<X509Certificate>();
/* 122 */       certList.add(pCertificate);
/* 124 */       if (Security.getProvider("BC") == null)
/* 125 */         Security.addProvider((Provider)new BouncyCastleProvider()); 
/* 128 */       cstore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(certList), "BC");
/* 131 */     } catch (Exception e) {
/* 132 */       e.printStackTrace();
/*     */     } 
/* 138 */     String LoginTicketRequest_xml = create_LoginTicketRequest(pSignerDN, dstDN, service, TicketTime);
/*     */     try {
/* 145 */       CMSSignedDataGenerator gen = new CMSSignedDataGenerator();
/* 148 */       gen.addSigner(pKey, pCertificate, CMSSignedDataGenerator.DIGEST_SHA1);
/* 151 */       gen.addCertificatesAndCRLs(cstore);
/* 154 */       CMSProcessableByteArray cMSProcessableByteArray = new CMSProcessableByteArray(LoginTicketRequest_xml.getBytes());
/* 157 */       CMSSignedData signed = gen.generate((CMSProcessable)cMSProcessableByteArray, true, "BC");
/* 160 */       asn1_cms = signed.getEncoded();
/* 162 */     } catch (Exception e) {
/* 163 */       e.printStackTrace();
/*     */     } 
/* 166 */     return asn1_cms;
/*     */   }
/*     */   
/*     */   private static String create_LoginTicketRequest(String SignerDN, String dstDN, String service, Long TicketTime) {
/* 176 */     Date GenTime = new Date();
/* 177 */     GregorianCalendar gentime = new GregorianCalendar();
/* 178 */     GregorianCalendar exptime = new GregorianCalendar();
/* 179 */     String UniqueId = (new Long(GenTime.getTime() / 1000L)).toString();
/* 181 */     gentime.setTime(new Date(GenTime.getTime() - 3000L));
/* 182 */     exptime.setTime(new Date(GenTime.getTime() + TicketTime.longValue()));
/* 184 */     XMLGregorianCalendarImpl XMLGenTime = new XMLGregorianCalendarImpl(gentime);
/* 185 */     XMLGregorianCalendarImpl XMLExpTime = new XMLGregorianCalendarImpl(exptime);
/* 187 */     String LoginTicketRequest_xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><loginTicketRequest version=\"1.0\"><header><source>" + SignerDN + "</source>" + "<destination>" + dstDN + "</destination>" + "<uniqueId>" + UniqueId + "</uniqueId>" + "<generationTime>" + XMLGenTime + "</generationTime>" + "<expirationTime>" + XMLExpTime + "</expirationTime>" + "</header>" + "<service>" + service + "</service>" + "</loginTicketRequest>";
/* 199 */     return LoginTicketRequest_xml;
/*     */   }
/*     */   
/*     */   private static String invoke_wsaa(byte[] LoginTicketRequest_xml_cms, String endpoint) throws Exception {
/* 204 */     String LoginTicketResponse = null;
/*     */     try {
/* 207 */       Service service = new Service();
/* 208 */       Call call = (Call)service.createCall();
/* 214 */       call.setTargetEndpointAddress(new URL(endpoint));
/* 215 */       call.setOperationName("loginCms");
/* 216 */       call.addParameter("request", XMLType.XSD_STRING, ParameterMode.IN);
/* 217 */       call.setReturnType(XMLType.XSD_STRING);
/* 219 */       String encoded = Base64.encode(LoginTicketRequest_xml_cms);
/* 224 */       LoginTicketResponse = (String)call.invoke(new Object[] { encoded });
/* 227 */     } catch (Exception e) {
/* 228 */       e.printStackTrace();
/*     */     } 
/* 230 */     return LoginTicketResponse;
/*     */   }
/*     */ }


/* Location:              C:\Users\ap255125\Downloads\ArgAFIPWS.jar!\argafipws\LoginService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */