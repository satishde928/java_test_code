/*    */ package argafipws;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.security.KeyStore;
/*    */ import java.security.PrivateKey;
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ public class ObjectLoginWS {
/*    */   private PrivateKey pKey;
/*    */   
/*    */   private X509Certificate pCertificate;
/*    */   
/*    */   private String SignerDN;
/*    */   
/*    */   private void $init$() {
/* 11 */     this.pKey = null;
/* 12 */     this.pCertificate = null;
/* 13 */     this.SignerDN = null;
/*    */   }
/*    */   
/*    */   public ObjectLoginWS(String p12file, String p12pass, String signer) {
/* 15 */     $init$();
/*    */     try {
/* 17 */       KeyStore ks = KeyStore.getInstance("pkcs12");
/* 18 */       FileInputStream p12stream = new FileInputStream(p12file);
/* 19 */       ks.load(p12stream, p12pass.toCharArray());
/* 20 */       p12stream.close();
/* 23 */       this.pKey = (PrivateKey)ks.getKey(signer, p12pass.toCharArray());
/* 25 */       this.pCertificate = (X509Certificate)ks.getCertificate(signer);
/* 27 */       this.SignerDN = this.pCertificate.getSubjectDN().toString();
/* 29 */     } catch (Exception e) {
/* 30 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public PrivateKey getPrivateKey() {
/* 38 */     return this.pKey;
/*    */   }
/*    */   
/*    */   public X509Certificate getCertificate() {
/* 42 */     return this.pCertificate;
/*    */   }
/*    */   
/*    */   public String getSignerDN() {
/* 47 */     return this.SignerDN;
/*    */   }
/*    */ }


/* Location:              C:\Users\ap255125\Downloads\ArgAFIPWS.jar!\argafipws\ObjectLoginWS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */