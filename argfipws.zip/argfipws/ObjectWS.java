/*     */ package argafipws;
/*     */ 
/*     */ public class ObjectWS {
/*     */   private String doc_type;
/*     */   
/*     */   private String doc_num;
/*     */   
/*     */   private String doc_pos;
/*     */   
/*     */   private String invoice_type;
/*     */   
/*     */   private String trx_number;
/*     */   
/*     */   private String ws_Login;
/*     */   
/*     */   private String ws_Url;
/*     */   
/*     */   private String ws_method;
/*     */   
/*     */   private String ws_name;
/*     */   
/*     */   private int customer_trx_id;
/*     */   
/*     */   private String xml_output;
/*     */   
/*     */   private String nombre_archivo;
/*     */   
/*     */   private Boolean Xmlerror;
/*     */   
/*     */   public ObjectWS(String doc_type, String doc_num, String doc_pos, String ws_Login, String ws_Url, String ws_method, String ws_name, String invoice_type, String trx_number, int customer_trx_id, String xml_output, String nombre_archivo) {
/*  25 */     this.doc_type = doc_type;
/*  26 */     this.doc_num = doc_num;
/*  27 */     this.doc_pos = doc_pos;
/*  28 */     this.ws_Login = ws_Login;
/*  29 */     this.ws_Url = ws_Url;
/*  30 */     this.ws_method = ws_method;
/*  31 */     this.ws_name = ws_name;
/*  32 */     this.invoice_type = invoice_type;
/*  33 */     this.trx_number = trx_number;
/*  34 */     this.customer_trx_id = customer_trx_id;
/*  36 */     this.xml_output = xml_output;
/*  37 */     this.nombre_archivo = nombre_archivo;
/*  38 */     this.Xmlerror = Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */   public Boolean getXmlerror() {
/*  44 */     return this.Xmlerror;
/*     */   }
/*     */   
/*     */   public void seteXmlerror(Boolean Xmlerror) {
/*  49 */     this.Xmlerror = Xmlerror;
/*     */   }
/*     */   
/*     */   public String getDoc_Type() {
/*  53 */     return this.doc_type;
/*     */   }
/*     */   
/*     */   public void setDoc_Type(String doc_type) {
/*  58 */     this.doc_type = doc_type;
/*     */   }
/*     */   
/*     */   public String getDoc_Num() {
/*  63 */     return this.doc_num;
/*     */   }
/*     */   
/*     */   public void setDoc_Num(String doc_num) {
/*  68 */     this.doc_num = doc_num;
/*     */   }
/*     */   
/*     */   public String getDoc_Pos() {
/*  73 */     return this.doc_pos;
/*     */   }
/*     */   
/*     */   public void setDoc_Pos(String doc_pos) {
/*  78 */     this.doc_pos = doc_pos;
/*     */   }
/*     */   
/*     */   public String getWS_Login() {
/*  84 */     return this.ws_Login;
/*     */   }
/*     */   
/*     */   public void setWS_Login(String ws_Login) {
/*  89 */     this.ws_Login = ws_Login;
/*     */   }
/*     */   
/*     */   public String getWS_Url() {
/*  94 */     return this.ws_Url;
/*     */   }
/*     */   
/*     */   public void setWS_Url(String ws_Url) {
/*  99 */     this.ws_Url = ws_Url;
/*     */   }
/*     */   
/*     */   public String getWS_Method() {
/* 104 */     return this.ws_method;
/*     */   }
/*     */   
/*     */   public void setWS_Metodo(String ws_metodo) {
/* 109 */     this.ws_method = ws_metodo;
/*     */   }
/*     */   
/*     */   public String getWS_Name() {
/* 114 */     return this.ws_name;
/*     */   }
/*     */   
/*     */   public void setWS_Name(String ws_name) {
/* 119 */     this.ws_name = ws_name;
/*     */   }
/*     */   
/*     */   public String getInvoice_Type() {
/* 124 */     return this.invoice_type;
/*     */   }
/*     */   
/*     */   public void setInvoice_Type(String invoice_type) {
/* 129 */     this.invoice_type = invoice_type;
/*     */   }
/*     */   
/*     */   public String getTrx_Number() {
/* 134 */     return this.trx_number;
/*     */   }
/*     */   
/*     */   public void setTrx_Number(String trx_number) {
/* 139 */     this.trx_number = trx_number;
/*     */   }
/*     */   
/*     */   public int getCustomer_Trx_Id() {
/* 144 */     return this.customer_trx_id;
/*     */   }
/*     */   
/*     */   public void setCustomer_Trx_Id(int customer_trx_id) {
/* 149 */     this.customer_trx_id = customer_trx_id;
/*     */   }
/*     */   
/*     */   public String getXml_Output() {
/* 154 */     return this.xml_output;
/*     */   }
/*     */   
/*     */   public void setXml_Output(String xml_output) {
/* 159 */     this.xml_output = xml_output;
/*     */   }
/*     */   
/*     */   public String getNombre_Archivo() {
/* 164 */     return this.nombre_archivo;
/*     */   }
/*     */   
/*     */   public void setNombre_Archivo(String nombre_archivo) {
/* 170 */     this.nombre_archivo = nombre_archivo;
/*     */   }
/*     */ }


/* Location:              C:\Users\ap255125\Downloads\ArgAFIPWS.jar!\argafipws\ObjectWS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */