/*     */ package argafipws;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class Params {
/*     */   private static String envName;
/*     */   
/*     */   private static String connectionType;
/*     */   
/*     */   private static String companyName;
/*     */   
/*     */   private static String companyCUIT;
/*     */   
/*     */   private static String companyDestination;
/*     */   
/*     */   private static String fileName;
/*     */   
/*     */   private static String signer;
/*     */   
/*     */   private static String password;
/*     */   
/*     */   private static String loginURL;
/*     */   
/*     */   private static String requestFilesPath;
/*     */   
/*     */   private static String responseFilesPath;
/*     */   
/*     */   private static String historyFilesPath;
/*     */   
/*     */   private static String responsePrefix;
/*     */   
/*     */   private static String JDBCURL;
/*     */   
/*     */   private static String JDBCUser;
/*     */   
/*     */   private static String JDBCPass;
/*     */   
/*     */   private static Connection JDBCconn;
/*     */   
/*     */   private static String ParametersViewName;
/*     */   
/*     */   private static String ElectronicInvoiceWSViewName;
/*     */   
/*     */   private static String ElectronicInvoiceWSTrxTableName;
/*     */   
/*     */   public static void LoadParams(String paramfileName) {
/*  55 */     Properties params = new Properties();
/*     */     try {
/*  58 */       params.load(new FileInputStream(paramfileName));
/*  60 */     } catch (FileNotFoundException e) {
/*  61 */       System.out.println("Error file parameters.properties not found");
/*  62 */       System.exit(1);
/*  64 */     } catch (IOException e) {
/*  65 */       System.out.println("Error reading file parameters.properties");
/*  66 */       System.exit(1);
/*     */     } 
/*  69 */     envName = params.getProperty("Environment.Name");
/*  71 */     connectionType = params.getProperty("Environment.ConnectionType");
/*  74 */     if (NotInList(connectionType, new String[] { "FILE", "DB" })) {
/*  76 */       System.out.println("Error in file parameters.properties");
/*  77 */       System.out.println("Parameter Environment.ConnectionType " + connectionType + " is not valid. The valid values are FILE or DB");
/*  78 */       System.exit(1);
/*     */     } 
/*  81 */     fileName = params.getProperty("Cert.Filename");
/*  82 */     signer = params.getProperty("Cert.Signer");
/*  83 */     password = params.getProperty("Cert.Password");
/*  86 */     companyName = params.getProperty("Company.Name");
/*  87 */     companyCUIT = params.getProperty("Company.CUIT");
/*  88 */     companyDestination = params.getProperty("Company.Destination");
/*  91 */     requestFilesPath = params.getProperty("Server.RequestFilesPath");
/*  92 */     responseFilesPath = params.getProperty("Server.ResponseFilesPath");
/*  93 */     historyFilesPath = params.getProperty("Server.ProcessedFilesPath");
/*  94 */     responsePrefix = params.getProperty("Server.ResponsePrefix");
/*  98 */     JDBCURL = params.getProperty("JDBC.URL");
/*  99 */     JDBCUser = params.getProperty("JDBC.Username");
/* 100 */     JDBCPass = params.getProperty("JDBC.Password");
/* 102 */     ParametersViewName = params.getProperty("DB.ParametersViewName");
/* 103 */     ElectronicInvoiceWSViewName = params.getProperty("DB.ElectronicInvoiceWSViewName");
/* 104 */     ElectronicInvoiceWSTrxTableName = params.getProperty("DB.ElectronicInvoiceWSTrxTableName");
/* 111 */     validateParams();
/* 132 */     System.out.println("Environment Parameters located on=" + connectionType + "\n");
/* 134 */     System.out.println("Company=" + companyName);
/* 135 */     System.out.println("CUIT=" + companyCUIT + "\n");
/* 148 */     if ("FILE".equals(connectionType)) {
/* 150 */       System.out.println("Running File Setup");
/* 151 */       System.out.println("---------------------------------------------");
/* 152 */       System.out.println("Login URL=" + loginURL);
/* 156 */       System.out.println("Request Files Location Path  = " + requestFilesPath);
/* 157 */       System.out.println("Response Files Location Path = " + responseFilesPath);
/* 158 */       System.out.println("Histoy Files Location Path   = " + historyFilesPath);
/* 161 */     } else if ("DB".equals(connectionType)) {
/* 162 */       System.out.println("Database setup");
/* 163 */       System.out.println("---------------------------------------------");
/* 164 */       System.out.println("Login URL=" + loginURL);
/* 168 */       System.out.println("JDBC URL                     = " + JDBCURL);
/* 169 */       System.out.println("USERNAME/PASSWORD            = " + JDBCUser + "/**********");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void validateParams() {
/* 177 */     if ("FILE".equals(connectionType)) {
/* 178 */       File testPath = new File(requestFilesPath);
/* 180 */       if (!testPath.exists() || testPath.isFile()) {
/* 181 */         System.out.println("Parameter Server.RequestFilesPath=" + requestFilesPath + " is empty or not exists, please verify and try again later");
/* 182 */         System.exit(1);
/*     */       } 
/* 185 */       File testPathO = new File(responseFilesPath);
/* 186 */       if (testPathO.isFile()) {
/* 187 */         System.out.println("Parameter Server.ResponseFilesPath=" + responseFilesPath + " is a file, please verify and try again later");
/* 188 */         System.exit(1);
/* 189 */       } else if (!testPathO.exists()) {
/* 190 */         testPathO.mkdir();
/*     */       } 
/* 194 */     } else if ("DB".equals(connectionType)) {
/*     */       try {
/*     */         try {
/* 198 */           Class.forName("oracle.jdbc.driver.OracleDriver");
/* 200 */         } catch (ClassNotFoundException e) {
/* 202 */           System.out.println("Where is your Oracle JDBC Driver?");
/* 203 */           e.printStackTrace();
/* 204 */           System.exit(1);
/*     */         } 
/* 208 */         System.out.println("Oracle JDBC Driver Registered!");
/*     */         try {
/* 212 */           JDBCconn = DriverManager.getConnection(JDBCURL, JDBCUser, JDBCPass);
/* 216 */         } catch (SQLException e) {
/* 218 */           System.out.println("Connection Failed! Check output console");
/* 219 */           e.printStackTrace();
/* 220 */           System.exit(1);
/*     */         } 
/* 241 */       } catch (SQLException e) {
/* 242 */         System.out.println("Error database " + e.getMessage());
/* 243 */         System.exit(1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getEnvName() {
/* 249 */     return envName;
/*     */   }
/*     */   
/*     */   public static String getConnectionType() {
/* 257 */     return connectionType;
/*     */   }
/*     */   
/*     */   public static String getCompanyCUIT() {
/* 261 */     return companyCUIT;
/*     */   }
/*     */   
/*     */   public static String getCompanyDestination() {
/* 265 */     return companyDestination;
/*     */   }
/*     */   
/*     */   public static String getFileName() {
/* 269 */     return fileName;
/*     */   }
/*     */   
/*     */   public static String getSigner() {
/* 273 */     return signer;
/*     */   }
/*     */   
/*     */   public static String getPassword() {
/* 277 */     return password;
/*     */   }
/*     */   
/*     */   public static String getLoginURL() {
/* 281 */     return loginURL;
/*     */   }
/*     */   
/*     */   public static String getRequestFilesPath() {
/* 297 */     return requestFilesPath;
/*     */   }
/*     */   
/*     */   public static String getResponseFilesPath() {
/* 301 */     return responseFilesPath;
/*     */   }
/*     */   
/*     */   public static String getHistoryFilesPath() {
/* 305 */     return historyFilesPath;
/*     */   }
/*     */   
/*     */   public static String getResponsePrefix() {
/* 309 */     return responsePrefix;
/*     */   }
/*     */   
/*     */   public static Connection getJDBCconn() {
/* 313 */     return JDBCconn;
/*     */   }
/*     */   
/*     */   public static String getElectronicInvoiceWSViewName() {
/* 317 */     return ElectronicInvoiceWSViewName;
/*     */   }
/*     */   
/*     */   public static String getParametersViewName() {
/* 321 */     return ParametersViewName;
/*     */   }
/*     */   
/*     */   public static String getElectronicInvoiceWSTrxTableName() {
/* 326 */     return ElectronicInvoiceWSTrxTableName;
/*     */   }
/*     */   
/*     */   public static void closeJDBCConnection() {
/*     */     try {
/* 334 */       JDBCconn.close();
/* 335 */     } catch (SQLException e) {
/* 336 */       System.out.println("Close Connection Error " + e.getMessage());
/* 337 */       System.exit(1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean NotInList(String inputString, String[] items) {
/* 344 */     for (int i = 0; i < items.length; i++) {
/* 346 */       if (inputString.contains(items[i]))
/* 348 */         return false; 
/*     */     } 
/* 351 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\ap255125\Downloads\ArgAFIPWS.jar!\argafipws\Params.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */