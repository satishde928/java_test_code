/*     */ package argafipws;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import javax.xml.soap.SOAPPart;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.apache.axis.SOAPPart;
/*     */ import org.apache.axis.client.Call;
/*     */ import org.apache.axis.client.Service;
/*     */ import org.apache.axis.message.SOAPEnvelope;
/*     */ import org.apache.axis.soap.MessageFactoryImpl;
/*     */ 
/*     */ public class WebServices {
/*     */   public static String Get_Response(String WebServiceTicketResponse, String servicio, String method) {
/*  31 */     String response = null;
/*  33 */     if ("wsmtxca".equals(servicio)) {
/*  35 */       WebServiceTicketResponse = WebServiceTicketResponse.replace(" xmlns:ns1=\"http://impl.service.wsmtxca.afip.gov.ar/service/\"", "");
/*  36 */       response = getXmlFromSoap(WebServiceTicketResponse, "ns1:" + method + "Response");
/*  38 */     } else if ("wsfex".equals(servicio)) {
/*  40 */       WebServiceTicketResponse = WebServiceTicketResponse.replace(" xmlns=\"http://ar.gov.afip.dif.fexv1/\"", "");
/*  41 */       response = getXmlFromSoap(WebServiceTicketResponse, method + "Response");
/*  44 */     } else if ("wsfe".equals(servicio)) {
/*  46 */       WebServiceTicketResponse = WebServiceTicketResponse.replace(" xmlns=\"http://ar.gov.afip.dif.FEV1/\"", "");
/*  47 */       response = getXmlFromSoap(WebServiceTicketResponse, method + "Response");
/*     */     } 
/*  50 */     return response;
/*     */   }
/*     */   
/*     */   private static String getXmlFromSoap(String xml, String delimiter) {
/*  55 */     String response = null;
/*  56 */     String regexString = Pattern.quote("<" + delimiter + ">") + "(.*?)" + Pattern.quote("</" + delimiter + ">");
/*  59 */     Pattern pattern = Pattern.compile(regexString, 32);
/*  61 */     Matcher matcher = pattern.matcher(xml);
/*  62 */     while (matcher.find())
/*  64 */       response = matcher.group(1); 
/*  66 */     return response;
/*     */   }
/*     */   
/*     */   public static String CallWebServices(ObjectWS Record, String token, String sign) {
/*  71 */     String WebServiceTicketResponse = null;
/*  72 */     String endpoint = null;
/*  73 */     System.setProperty("http.proxyHost", "");
/*  74 */     System.setProperty("http.proxyPort", "80");
/*  77 */     endpoint = Record.getWS_Url();
/*  79 */     Long cuit = Long.valueOf(Long.parseLong(Params.getCompanyCUIT()));
/*  80 */     String service = Record.getWS_Name();
/*  83 */     String WebServiceTicketRequest_xml = create_WebServiceTicketRequest(service, Record.getWS_Method(), token, sign, cuit, Record.getXml_Output());
/*     */     try {
/*  88 */       WebServiceTicketResponse = invoke_WebService(WebServiceTicketRequest_xml, endpoint, service, Record.getWS_Method(), Record);
/*  90 */     } catch (Exception e) {
/*  93 */       e.printStackTrace();
/*     */     } 
/*  96 */     return WebServiceTicketResponse;
/*     */   }
/*     */   
/*     */   private static String create_WebServiceTicketRequest(String service, String method, String token, String sign, Long cuit, String xml_output) {
/* 108 */     String WebServiceTicketRequest_xml = null;
/* 109 */     if ("wsmtxca".equals(service)) {
/* 110 */       WebServiceTicketRequest_xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://impl.service.wsmtxca.afip.gov.ar/service/\"><soapenv:Header/><soapenv:Body><ser:" + method + "Request>" + "<authRequest>" + "<token>" + token + "</token>" + "<sign>" + sign + "</sign>" + "<cuitRepresentada>" + cuit + "</cuitRepresentada>" + "</authRequest>" + xml_output + "</ser:" + method + "Request>" + "</soapenv:Body>" + "</soapenv:Envelope>";
/* 124 */     } else if ("wsfex".equals(service)) {
/* 125 */       WebServiceTicketRequest_xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Header/><soap:Body><" + method + " xmlns=\"http://ar.gov.afip.dif.fexv1/\">" + "<Auth>" + "<Token>" + token + "</Token>" + "<Sign>" + sign + "</Sign>" + "<Cuit>" + cuit + "</Cuit>" + "</Auth>" + xml_output + "</" + method + ">" + "</soap:Body>" + "</soap:Envelope>";
/* 139 */     } else if ("wsfe".equals(service)) {
/* 140 */       WebServiceTicketRequest_xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><" + method + " xmlns=\"http://ar.gov.afip.dif.FEV1/\">" + "<Auth>" + "<Token>" + token + "</Token>" + "<Sign>" + sign + "</Sign>" + "<Cuit>" + cuit + "</Cuit>" + "</Auth>" + xml_output + "</" + method + ">" + "</soap:Body>" + "</soap:Envelope>";
/*     */     } 
/* 153 */     System.out.println("TRA Web Service: " + WebServiceTicketRequest_xml);
/* 155 */     return WebServiceTicketRequest_xml;
/*     */   }
/*     */   
/*     */   private static String invoke_WebService(String WebServiceTicketRequest_xml, String endpoint, String service, String method, ObjectWS Record) throws Exception {
/* 160 */     String WebServiceTicketResponse = null;
/*     */     try {
/* 163 */       Service serv = new Service();
/* 164 */       Call call = (Call)serv.createCall();
/* 170 */       String xmlInput = WebServiceTicketRequest_xml;
/* 171 */       byte[] reqBytes = xmlInput.getBytes();
/* 172 */       ByteArrayInputStream bis = new ByteArrayInputStream(reqBytes);
/* 173 */       StreamSource ss = new StreamSource(bis);
/* 174 */       MessageFactoryImpl messageFactory = new MessageFactoryImpl();
/* 175 */       SOAPMessage msg = messageFactory.createMessage();
/* 176 */       SOAPPart soapPart = msg.getSOAPPart();
/* 177 */       soapPart.setContent(ss);
/* 179 */       if ("wsfex".equals(service)) {
/* 181 */         call.setSOAPActionURI("http://ar.gov.afip.dif.fexv1/" + method);
/* 183 */       } else if ("wsfe".equals(service)) {
/* 184 */         call.setSOAPActionURI("http://ar.gov.afip.dif.FEV1/" + method);
/*     */       } 
/* 187 */       call.setTargetEndpointAddress(endpoint);
/* 190 */       SOAPEnvelope sOAPEnvelope = call.invoke(((SOAPPart)soapPart).getAsSOAPEnvelope());
/* 192 */       WebServiceTicketResponse = sOAPEnvelope.toString();
/* 194 */     } catch (Exception e) {
/* 195 */       Record.seteXmlerror(Boolean.valueOf(true));
/* 196 */       Record.setXml_Output("<resultado>X</resultado><arrayErrores><codigoDescripcion><codigo>102</codigo><descripcion>" + e.getMessage() + "</descripcion></codigoDescripcion></arrayErrores>");
/* 199 */       e.printStackTrace();
/*     */     } 
/* 202 */     return WebServiceTicketResponse;
/*     */   }
/*     */ }


/* Location:              C:\Users\ap255125\Downloads\ArgAFIPWS.jar!\argafipws\WebServices.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */