package com.argfipws;

public class AccessToken {
    private String token;

    private String sign;

    private String expiryDate;

    public AccessToken(String token, String sign, String expiryDate) {
        this.token = token;
        this.sign = sign;
        this.expiryDate = expiryDate;
    }

    public String getToken() {
        return this.token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getSign() {
        return this.sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getExpiryDate() {
        return this.expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }
}
