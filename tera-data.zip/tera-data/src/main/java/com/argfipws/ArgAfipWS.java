package com.argfipws;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class ArgAfipWS {
    static final Logger logger = Logger.getLogger(ArgAfipWS.class);

    public static void main(String[] args) {
        String log4jConfPath = "./log4j.properties";
        PropertyConfigurator.configure(log4jConfPath);
        if (logger.isInfoEnabled())
            logger.info("This is info1 : ");
        Params.LoadParams("./parameters.properties");
        if ("FILE".equals(Params.getConnectionType())) {
            ArrayList<ObjectWS> ListaObjectWS = FileLoadArray.Get_Array_List();
            CallAfipWebService(ListaObjectWS);
            FileLoadArray.Write_Response_To_Xml(ListaObjectWS);
        } else if ("DB".equals(Params.getConnectionType())) {
            ArrayList<ObjectWS> ListaObjectWS = DBLoadArray.Get_Array_List();
            CallAfipWebService(ListaObjectWS);
            DBLoadArray.Write_Response_To_DB(ListaObjectWS);
            try {
                Params.getJDBCconn().close();
            } catch (SQLException e) {
                System.out.println("Error database " + e.getMessage());
                System.exit(1);
            }
        }
    }

    private static void CallAfipWebService(ArrayList<ObjectWS> ListaObjectWS) {
        String Last_Service = "_blank";
        String token = null;
        String sign = null;
        String WS_Login_URL = null;
        ObjectLoginWS objectLogin = new ObjectLoginWS(Params.getFileName(), Params.getPassword(), Params.getSigner());
        if (objectLogin.getPrivateKey() == null) {
            System.out.println("Certificate Error.Please contact System Administrator");
            System.exit(1);
        }
        for (ObjectWS Record : ListaObjectWS) {
            System.out.println("");
            String psService = Record.getWS_Name();
            if (Last_Service.compareTo(psService) != 0) {
                String psWS_Login_URl = Record.getWS_Login();
                Last_Service = psService;
                System.out.println("Login Service Login: " + psWS_Login_URl);
                System.out.println("Login Service Name: " + psService);
                AccessToken AccessTokenObj = LoginService.callLoginService(psWS_Login_URl, psService, objectLogin.getPrivateKey(), objectLogin.getCertificate(), objectLogin.getSignerDN());
                token = AccessTokenObj.getToken();
                sign = AccessTokenObj.getSign();
            }
            System.out.println("CallWebServices ");
            System.out.println("     Invoice_Type:" + Record.getInvoice_Type());
            System.out.println("      Trx_Number:" + Record.getTrx_Number());
            System.out.println("      Customer_Trx_Id:" + Record.getCustomer_Trx_Id());
            String WebServiceTicketResponse = WebServices.CallWebServices(Record, token, sign);
            if (!Record.getXmlerror().booleanValue()) {
                String ResponseXML = WebServices.Get_Response(WebServiceTicketResponse, psService, Record.getWS_Method());
                System.out.println("Response: " + ResponseXML);
                Record.setXml_Output(ResponseXML);
            }
        }
    }
}

 