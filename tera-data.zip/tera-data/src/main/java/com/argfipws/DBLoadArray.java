package com.argfipws;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

public class DBLoadArray {
    public static ArrayList<ObjectWS> Get_Array_List() {
        ArrayList<ObjectWS> ListaObjectWS = new ArrayList<ObjectWS>();
        try {
            Statement sqlStmt = Params.getJDBCconn().createStatement();
            ResultSet qresult = sqlStmt.executeQuery("SELECT * FROM " + Params.getElectronicInvoiceWSViewName());
            if (!qresult.isBeforeFirst()) {
                System.out.println("**** NO DATA FOUND ****");
                System.out.println("No pending Transaction to be processed.");
            }
            while (qresult.next()) {
                System.out.println("Adding Transaction " + qresult.getString("INVOICE_TYPE") + " " + qresult.getString("TRX_NUMBER"));
                String Doc_Type = qresult.getString("DOCUMENT_TYPE");
                String Doc_Num = qresult.getString("NRO_DOC");
                String Doc_Pos = qresult.getString("PTOVTA");
                String WS_Login = qresult.getString("WS_LOGIN_URL");
                String WS_Metodo = qresult.getString("WS_METHOD");
                String WS_Name = qresult.getString("WS_SERVICE");
                String WS_Url = qresult.getString("WS_URL");
                int Customer_Trx_Id = qresult.getInt("CUSTOMER_TRX_ID");
                String Trx_Number = qresult.getString("TRX_NUMBER");
                String Invoice_Type = qresult.getString("INVOICE_TYPE");
                String xml_output = qresult.getString("XML_OUTPUT");
                String nombre_archivo = null;
                ObjectWS ObjectWS_Return = new ObjectWS(Doc_Type, Doc_Num, Doc_Pos, WS_Login, WS_Url, WS_Metodo, WS_Name, Invoice_Type, Trx_Number, Customer_Trx_Id, xml_output, nombre_archivo);
                ListaObjectWS.add(ObjectWS_Return);
            }
            qresult.close();
        } catch (SQLException e) {
            System.out.println("Error database " + e.getMessage());
            System.exit(1);
        }
        ListaObjectWS.trimToSize();
        return ListaObjectWS;
    }

    public static void Write_Response_To_DB(ArrayList<ObjectWS> ListaObjectWS) {
        PreparedStatement preparedStatement = null;
        String insertSQL = "INSERT INTO " + Params.getElectronicInvoiceWSTrxTableName() + " ( XXSBC_AR_ARFE_WS_TRX_ID" + " ,CUSTOMER_TRX_ID" + ", AFIP_RESPONSE_XML" + ", STATUS" + ", WS_URL" + ", WS_NAME" + ", WS_METHOD" + ", CREATED_BY" + ", CREATION_DATE" + ", LAST_UPDATED_BY" + ", LAST_UPDATE_DATE" + ", LAST_UPDATE_LOGIN)" + " SELECT XXSBC_AR_ARFE_WS_TRX_S.NEXTVAL" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?" + ", ?  FROM DUAL";
        for (ObjectWS Record : ListaObjectWS) {
            try {
                preparedStatement = Params.getJDBCconn().prepareStatement(insertSQL);
                preparedStatement.setInt(1, Record.getCustomer_Trx_Id());
                preparedStatement.setString(2, Record.getXml_Output());
                preparedStatement.setString(3, "PENDING");
                preparedStatement.setString(4, Record.getWS_Url());
                preparedStatement.setString(5, Record.getWS_Name());
                preparedStatement.setString(6, Record.getWS_Method());
                preparedStatement.setInt(7, -1);
                preparedStatement.setTimestamp(8, getCurrentTimeStamp());
                preparedStatement.setInt(9, -1);
                preparedStatement.setTimestamp(10, getCurrentTimeStamp());
                preparedStatement.setInt(11, -1);
                preparedStatement.executeUpdate();
                preparedStatement.close();
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                System.exit(1);
            }
        }
    }

    private static Timestamp getCurrentTimeStamp() {
        Date today = new Date();
        return new Timestamp(today.getTime());
    }
}

 