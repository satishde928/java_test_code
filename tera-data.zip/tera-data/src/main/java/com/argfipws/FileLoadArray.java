package com.argfipws;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.comparator.NameFileComparator;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;


class FileLoadArray {
    public static ArrayList<ObjectWS> Get_Array_List() {
        ArrayList<ObjectWS> ListaObjectWS = new ArrayList<ObjectWS>();
        String requestFilesPath = Params.getRequestFilesPath();
        File ruta = new File(requestFilesPath);
        File[] archivos = ruta.listFiles(new FilenameFilter() {
            public boolean accept(File directory, String fileName) {
                if (fileName.endsWith(".xml"))
                    return true;
                return false;
            }
        });
        Arrays.sort(archivos, NameFileComparator.NAME_COMPARATOR);
        System.out.println("");
        System.out.println("Archivos a procesar");
        File[] arrayOfFile1;
        byte b;
        for (arrayOfFile1 = archivos, b = 0; b < arrayOfFile1.length; ) {
            File f = arrayOfFile1[b];
            System.out.println("\t" + f.getAbsolutePath());
            ObjectWS ObjectWS_Return = Get_Object_Array(f);
            ListaObjectWS.add(ObjectWS_Return);
            b++;
        }
        ListaObjectWS.trimToSize();
        return ListaObjectWS;
    }

    private static ObjectWS Get_Object_Array(File xmlFile) {
        SAXBuilder builder = new SAXBuilder();
        try {
            Document document = builder.build(xmlFile);
            String nombre_archivo = xmlFile.getName();
            Element rootNode = document.getRootElement();
            String xml_output = rootNode.getChildTextTrim("XML_OUTPUT");
            List<?> list = rootNode.getChildren("XX_WS_INFO");
            Element tabla = (Element) list.get(0);
            String Doc_Type = tabla.getChildTextTrim("DOCUMENT_TYPE");
            String Doc_Num = tabla.getChildTextTrim("NRO_DOC");
            String Doc_Pos = tabla.getChildTextTrim("PTOVTA");
            String Invoice_Type = tabla.getChildTextTrim("INVOICE_TYPE");
            String Trx_Number = tabla.getChildTextTrim("TRX_NUMBER");
            String WS_Login = tabla.getChildTextTrim("WS_LOGIN_URL");
            String WS_Url = tabla.getChildTextTrim("WS_URL");
            String WS_Method = tabla.getChildTextTrim("WS_METHOD");
            String WS_Name = tabla.getChildTextTrim("WS_SERVICE");
            int Customer_Trx_Id = Integer.parseInt(tabla.getChildTextTrim("CUSTOMER_TRX_ID"));
            return new ObjectWS(Doc_Type, Doc_Num, Doc_Pos, WS_Login, WS_Url, WS_Method, WS_Name, Invoice_Type, Trx_Number, Customer_Trx_Id, xml_output, nombre_archivo);
        } catch (IOException io) {
            System.out.println(io.getMessage());
        } catch (JDOMException jdomex) {
            System.out.println(jdomex.getMessage());
        }
        return null;
    }

    public static void Write_Response_To_Xml(ArrayList<ObjectWS> ListaObjectWS) {
        for (ObjectWS Record : ListaObjectWS) {
            String nombreArchivo = Record.getNombre_Archivo().replace("Request_", Params.getResponsePrefix());
            String xmlGeneral = "<XX_Main><XX_WS_INFO><WS_SERVICE>" + Record.getWS_Name() + "</WS_SERVICE>" + "<WS_METHOD>" + Record.getWS_Method() + "</WS_METHOD>" + "<WS_URL>" + Record.getWS_Url() + "</WS_URL>" + "<INVOICE_TYPE>" + Record.getInvoice_Type() + "</INVOICE_TYPE>" + "<TRX_NUMBER>" + Record.getTrx_Number() + "</TRX_NUMBER>" + "<DOCUMENT_TYPE>" + Record.getDoc_Type() + "</DOCUMENT_TYPE>" + "<NRO_DOC>" + Record.getDoc_Num() + "</NRO_DOC>" + "<PTOVTA>" + Record.getDoc_Pos() + "</PTOVTA>" + "<CUSTOMER_TRX_ID>" + Record.getCustomer_Trx_Id() + "</CUSTOMER_TRX_ID>" + "</XX_WS_INFO>" + "<XML_OUTPUT>![CDATA[" + Record.getXml_Output() + "]]</XML_OUTPUT>" + "</XX_Main>";
            String rutaArchivo = Params.getResponseFilesPath() + "//" + nombreArchivo;
            File archivo = new File(rutaArchivo);
            try {
                BufferedWriter bw = new BufferedWriter(new FileWriter(archivo));
                bw.write(xmlGeneral);
                bw.close();
                if (Params.getHistoryFilesPath().compareTo("") != 0) {
                    DateFormat df = new SimpleDateFormat("yyyyMMdd_HHmmss");
                    Date today = Calendar.getInstance().getTime();
                    String reportDate = df.format(today);
                    InputStream in = null;
                    OutputStream out = null;
                    try {
                        File oldFile = new File(Params.getRequestFilesPath() + "//" + Record.getNombre_Archivo());
                        File newFile = new File(Params.getHistoryFilesPath() + "//" + Record.getNombre_Archivo() + "." + reportDate);
                        in = new FileInputStream(oldFile);
                        out = new FileOutputStream(newFile);
                        byte[] moveBuff = new byte[1024];
                        int butesRead;
                        while ((butesRead = in.read(moveBuff)) > 0)
                            out.write(moveBuff, 0, butesRead);
                        in.close();
                        out.close();
                        oldFile.delete();
                        System.out.println("File " + Params.getRequestFilesPath() + "//" + Record.getNombre_Archivo() + "  was successfully moved to " + Params.getHistoryFilesPath() + "//" + Record.getNombre_Archivo() + "." + reportDate);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
