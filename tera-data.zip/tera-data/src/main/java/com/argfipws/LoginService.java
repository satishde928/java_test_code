package com.argfipws;



import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.Security;
import java.security.cert.CertStore;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;


import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.encoding.Base64;
import org.apache.axis.encoding.XMLType;
import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;
//import org.apache.xerces.jaxp.datatype.DatatypeFactoryImpl;


import org.bouncycastle.cms.CMSProcessable;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.dom4j.Document;
import org.dom4j.io.SAXReader;

import javax.xml.rpc.ParameterMode;

public class LoginService {
    public static AccessToken callLoginService(String endpoint, String psService, PrivateKey pKey, X509Certificate pCertificate, String pSignerDN) {
        String LoginTicketResponse = null;
        System.setProperty("http.proxyHost", "");
        System.setProperty("http.proxyPort", "80");
        String dstDN = Params.getCompanyDestination();
        String service = psService;
        Long TicketTime = Long.valueOf(3600000L);
        byte[] LoginTicketRequest_xml_cms = create_cms(pKey, pCertificate, pSignerDN, dstDN, service, TicketTime);
        try {
            LoginTicketResponse = invoke_wsaa(LoginTicketRequest_xml_cms, endpoint);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            Reader tokenReader = new StringReader(LoginTicketResponse);
            Document tokenDoc = (new SAXReader(false)).read(tokenReader);
            String token = tokenDoc.valueOf("/loginTicketResponse/credentials/token");
            String sign = tokenDoc.valueOf("/loginTicketResponse/credentials/sign");
            String expiryDate = tokenDoc.valueOf("/loginTicketResponse/header/expirationTime");
            return new AccessToken(token, sign, expiryDate);
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

    private static byte[] create_cms(PrivateKey pKey, X509Certificate pCertificate, String pSignerDN, String dstDN, String service, Long TicketTime) {
        byte[] asn1_cms = null;
        CertStore cstore = null;
        try {
            ArrayList<X509Certificate> certList = new ArrayList<X509Certificate>();
            certList.add(pCertificate);
            if (Security.getProvider("BC") == null)
                Security.addProvider((Provider) new BouncyCastleProvider());
            cstore = CertStore.getInstance("Collection", new CollectionCertStoreParameters(certList), "BC");
        } catch (Exception e) {
            e.printStackTrace();
        }
        String LoginTicketRequest_xml = create_LoginTicketRequest(pSignerDN, dstDN, service, TicketTime);
        try {
            CMSSignedDataGenerator gen = new CMSSignedDataGenerator();
            gen.addSigner(pKey, pCertificate, CMSSignedDataGenerator.DIGEST_SHA1);
            gen.addCertificatesAndCRLs(cstore);
            CMSProcessableByteArray cMSProcessableByteArray = new CMSProcessableByteArray(LoginTicketRequest_xml.getBytes());
            CMSSignedData signed = gen.generate((CMSProcessable) cMSProcessableByteArray, true, "BC");
            asn1_cms = signed.getEncoded();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asn1_cms;
    }

    private static String create_LoginTicketRequest(String SignerDN, String dstDN, String service, Long TicketTime) {
        Date GenTime = new Date();
        GregorianCalendar gentime = new GregorianCalendar();
        GregorianCalendar exptime = new GregorianCalendar();
        String UniqueId = (Long.valueOf(GenTime.getTime() / 1000L)).toString();
        gentime.setTime(new Date(GenTime.getTime() - 3000L));
        exptime.setTime(new Date(GenTime.getTime() + TicketTime.longValue()));
        XMLGregorianCalendarImpl XMLGenTime = new XMLGregorianCalendarImpl(gentime);
        XMLGregorianCalendarImpl XMLExpTime = new XMLGregorianCalendarImpl(exptime);
        String LoginTicketRequest_xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><loginTicketRequest version=\"1.0\"><header><source>" + SignerDN + "</source>" + "<destination>" + dstDN + "</destination>" + "<uniqueId>" + UniqueId + "</uniqueId>" + "<generationTime>" + XMLGenTime + "</generationTime>" + "<expirationTime>" + XMLExpTime + "</expirationTime>" + "</header>" + "<service>" + service + "</service>" + "</loginTicketRequest>";
        return LoginTicketRequest_xml;
    }

    private static String invoke_wsaa(byte[] LoginTicketRequest_xml_cms, String endpoint) throws Exception {
        String LoginTicketResponse = null;
        try {
            Service service = new Service();
            Call call = (Call) service.createCall();
            call.setTargetEndpointAddress(new URL(endpoint));
            call.setOperationName("loginCms");
            call.addParameter("request", XMLType.XSD_STRING, ParameterMode.IN);
            call.setReturnType(XMLType.XSD_STRING);
            String encoded = Base64.encode(LoginTicketRequest_xml_cms);
            LoginTicketResponse = (String) call.invoke(new Object[]{encoded});
        } catch (Exception e) {
            e.printStackTrace();
        }
        return LoginTicketResponse;
    }
}

 