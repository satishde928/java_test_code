package com.argfipws;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;

public class ObjectLoginWS {
    private PrivateKey pKey;

    private X509Certificate pCertificate;

    private String SignerDN;

    private void $init$() {
        this.pKey = null;
        this.pCertificate = null;
        this.SignerDN = null;
    }

    public ObjectLoginWS(String p12file, String p12pass, String signer) {
        $init$();
        try {
            KeyStore ks = KeyStore.getInstance("pkcs12");
            FileInputStream p12stream = new FileInputStream(p12file);
            ks.load(p12stream, p12pass.toCharArray());
            p12stream.close();
            this.pKey = (PrivateKey) ks.getKey(signer, p12pass.toCharArray());
            this.pCertificate = (X509Certificate) ks.getCertificate(signer);
            this.SignerDN = this.pCertificate.getSubjectDN().toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public PrivateKey getPrivateKey() {
        return this.pKey;
    }

    public X509Certificate getCertificate() {
        return this.pCertificate;
    }

    public String getSignerDN() {
        return this.SignerDN;
    }
}

 