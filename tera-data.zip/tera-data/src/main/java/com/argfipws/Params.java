package com.argfipws;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Params {
    private static String envName;

    private static String connectionType;

    private static String companyName;

    private static String companyCUIT;

    private static String companyDestination;

    private static String fileName;

    private static String signer;

    private static String password;

    private static String loginURL;

    private static String requestFilesPath;

    private static String responseFilesPath;

    private static String historyFilesPath;

    private static String responsePrefix;

    private static String JDBCURL;

    private static String JDBCUser;

    private static String JDBCPass;

    private static Connection JDBCconn;

    private static String ParametersViewName;

    private static String ElectronicInvoiceWSViewName;

    private static String ElectronicInvoiceWSTrxTableName;

    public static void LoadParams(String paramfileName) {
        Properties params = new Properties();
        try {
            params.load(new FileInputStream(paramfileName));
        } catch (FileNotFoundException e) {
            System.out.println("Error file parameters.properties not found");
            System.exit(1);
        } catch (IOException e) {
            System.out.println("Error reading file parameters.properties");
            System.exit(1);
        }
        envName = params.getProperty("Environment.Name");
        connectionType = params.getProperty("Environment.ConnectionType");
        if (NotInList(connectionType, new String[]{"FILE", "DB"})) {
            System.out.println("Error in file parameters.properties");
            System.out.println("Parameter Environment.ConnectionType " + connectionType + " is not valid. The valid values are FILE or DB");
            System.exit(1);
        }
        fileName = params.getProperty("Cert.Filename");
        signer = params.getProperty("Cert.Signer");
        password = params.getProperty("Cert.Password");
        companyName = params.getProperty("Company.Name");
        companyCUIT = params.getProperty("Company.CUIT");
        companyDestination = params.getProperty("Company.Destination");
        requestFilesPath = params.getProperty("Server.RequestFilesPath");
        responseFilesPath = params.getProperty("Server.ResponseFilesPath");
        historyFilesPath = params.getProperty("Server.ProcessedFilesPath");
        responsePrefix = params.getProperty("Server.ResponsePrefix");
        JDBCURL = params.getProperty("JDBC.URL");
        JDBCUser = params.getProperty("JDBC.Username");
        JDBCPass = params.getProperty("JDBC.Password");
        ParametersViewName = params.getProperty("DB.ParametersViewName");
        ElectronicInvoiceWSViewName = params.getProperty("DB.ElectronicInvoiceWSViewName");
        ElectronicInvoiceWSTrxTableName = params.getProperty("DB.ElectronicInvoiceWSTrxTableName");
        validateParams();
        System.out.println("Environment Parameters located on=" + connectionType + "\n");
        System.out.println("Company=" + companyName);
        System.out.println("CUIT=" + companyCUIT + "\n");
        if ("FILE".equals(connectionType)) {
            System.out.println("Running File Setup");
            System.out.println("---------------------------------------------");
            System.out.println("Login URL=" + loginURL);
            System.out.println("Request Files Location Path  = " + requestFilesPath);
            System.out.println("Response Files Location Path = " + responseFilesPath);
            System.out.println("Histoy Files Location Path   = " + historyFilesPath);
        } else if ("DB".equals(connectionType)) {
            System.out.println("Database setup");
            System.out.println("---------------------------------------------");
            System.out.println("Login URL=" + loginURL);
            System.out.println("JDBC URL                     = " + JDBCURL);
            System.out.println("USERNAME/PASSWORD            = " + JDBCUser + "*********");
        }
    }

    public static void validateParams() {
        if ("FILE".equals(connectionType)) {
            File testPath = new File(requestFilesPath);
            if (!testPath.exists() || testPath.isFile()) {
                System.out.println("Parameter Server.RequestFilesPath=" + requestFilesPath + " is empty or not exists, please verify and try again later");
                System.exit(1);
            }
            File testPathO = new File(responseFilesPath);
            if (testPathO.isFile()) {
                System.out.println("Parameter Server.ResponseFilesPath=" + responseFilesPath + " is a file, please verify and try again later");
                System.exit(1);
            } else if (!testPathO.exists()) {
                testPathO.mkdir();
            }
        } else if ("DB".equals(connectionType)) {
            try {
                try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                } catch (ClassNotFoundException e) {
                    System.out.println("Where is your Oracle JDBC Driver?");
                    e.printStackTrace();
                    System.exit(1);
                }
                System.out.println("Oracle JDBC Driver Registered!");
                try {
                    JDBCconn = DriverManager.getConnection(JDBCURL, JDBCUser, JDBCPass);
                } catch (SQLException e) {
                    System.out.println("Connection Failed! Check output console");
                    e.printStackTrace();
                    System.exit(1);
                }
            } catch (Exception e) {
                System.out.println("Error database " + e.getMessage());
                System.exit(1);
            }
        }
    }

    public static String getEnvName() {
        return envName;
    }

    public static String getConnectionType() {
        return connectionType;
    }

    public static String getCompanyCUIT() {
        return companyCUIT;
    }

    public static String getCompanyDestination() {
        return companyDestination;
    }

    public static String getFileName() {
        return fileName;
    }

    public static String getSigner() {
        return signer;
    }

    public static String getPassword() {
        return password;
    }

    public static String getLoginURL() {
        return loginURL;
    }

    public static String getRequestFilesPath() {
        return requestFilesPath;
    }

    public static String getResponseFilesPath() {
        return responseFilesPath;
    }

    public static String getHistoryFilesPath() {
        return historyFilesPath;
    }

    public static String getResponsePrefix() {
        return responsePrefix;
    }

    public static Connection getJDBCconn() {
        return JDBCconn;
    }

    public static String getElectronicInvoiceWSViewName() {
        return ElectronicInvoiceWSViewName;
    }

    public static String getParametersViewName() {
        return ParametersViewName;
    }

    public static String getElectronicInvoiceWSTrxTableName() {
        return ElectronicInvoiceWSTrxTableName;
    }

    public static void closeJDBCConnection() {
        try {
            JDBCconn.close();
        } catch (SQLException e) {
            System.out.println("Close Connection Error " + e.getMessage());
            System.exit(1);
        }
    }

    private static boolean NotInList(String inputString, String[] items) {
        for (int i = 0; i < items.length; i++) {
            if (inputString.contains(items[i]))
                return false;
        }
        return true;
    }
}

 