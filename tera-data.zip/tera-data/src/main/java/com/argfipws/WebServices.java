package com.argfipws;

import java.io.ByteArrayInputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.stream.StreamSource;


import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.axis.message.SOAPEnvelope;
import org.apache.axis.soap.MessageFactoryImpl;


public class WebServices {
    public static String Get_Response(String WebServiceTicketResponse, String servicio, String method) {
        String response = null;
        if ("wsmtxca".equals(servicio)) {
            WebServiceTicketResponse = WebServiceTicketResponse.replace(" xmlns:ns=\"http://impl.service.wsmtxca.afip.gov.ar/service/\"", "");
            response = getXmlFromSoap(WebServiceTicketResponse, "ns:" + method + "Response");
        } else if ("wsfex".equals(servicio)) {
            WebServiceTicketResponse = WebServiceTicketResponse.replace(" xmlns=\"http://ar.gov.afip.dif.fexv/\"", "");
            response = getXmlFromSoap(WebServiceTicketResponse, method + "Response");
        } else if ("wsfe".equals(servicio)) {
            WebServiceTicketResponse = WebServiceTicketResponse.replace(" xmlns=\"http://ar.gov.afip.dif.FEV/\"", "");
            response = getXmlFromSoap(WebServiceTicketResponse, method + "Response");
        }
        return response;
    }

    private static String getXmlFromSoap(String xml, String delimiter) {
        String response = null;
        String regexString = Pattern.quote("<" + delimiter + ">") + "(.*?)" + Pattern.quote("</" + delimiter + ">");
        Pattern pattern = Pattern.compile(regexString, 32);
        Matcher matcher = pattern.matcher(xml);
        while (matcher.find())
            response = matcher.group();
        return response;
    }

    public static String CallWebServices(ObjectWS Record, String token, String sign) {
        String WebServiceTicketResponse = null;
        String endpoint = null;
        System.setProperty("http.proxyHost", "");
        System.setProperty("http.proxyPort", "");
        endpoint = Record.getWS_Url();
        Long cuit = Long.valueOf(Long.parseLong(Params.getCompanyCUIT()));
        String service = Record.getWS_Name();
        String WebServiceTicketRequest_xml = create_WebServiceTicketRequest(service, Record.getWS_Method(), token, sign, cuit, Record.getXml_Output());
        try {
            WebServiceTicketResponse = invoke_WebService(WebServiceTicketRequest_xml, endpoint, service, Record.getWS_Method(), Record);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return WebServiceTicketResponse;
    }

    private static String create_WebServiceTicketRequest(String service, String method, String token, String sign, Long cuit, String xml_output) {
        String WebServiceTicketRequest_xml = null;
        if ("wsmtxca".equals(service)) {
            WebServiceTicketRequest_xml = "<?xml version=\".\" encoding=\"UTF-\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ser=\"http://impl.service.wsmtxca.afip.gov.ar/service/\"><soapenv:Header/><soapenv:Body><ser:" + method + "Request>" + "<authRequest>" + "<token>" + token + "</token>" + "<sign>" + sign + "</sign>" + "<cuitRepresentada>" + cuit + "</cuitRepresentada>" + "</authRequest>" + xml_output + "</ser:" + method + "Request>" + "</soapenv:Body>" + "</soapenv:Envelope>";
        } else if ("wsfex".equals(service)) {
            WebServiceTicketRequest_xml = "<?xml version=\".\" encoding=\"UTF-\"?><soap:Envelope xmlns:xsi=\"http://www.w.org//XMLSchema-instance\" xmlns:xsd=\"http://www.w.org//XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Header/><soap:Body><" + method + " xmlns=\"http://ar.gov.afip.dif.fexv/\">" + "<Auth>" + "<Token>" + token + "</Token>" + "<Sign>" + sign + "</Sign>" + "<Cuit>" + cuit + "</Cuit>" + "</Auth>" + xml_output + "</" + method + ">" + "</soap:Body>" + "</soap:Envelope>";
        } else if ("wsfe".equals(service)) {
            WebServiceTicketRequest_xml = "<?xml version=\".\" encoding=\"UTF-\"?><soap:Envelope xmlns:xsi=\"http://www.w.org//XMLSchema-instance\" xmlns:xsd=\"http://www.w.org//XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><" + method + " xmlns=\"http://ar.gov.afip.dif.FEV/\">" + "<Auth>" + "<Token>" + token + "</Token>" + "<Sign>" + sign + "</Sign>" + "<Cuit>" + cuit + "</Cuit>" + "</Auth>" + xml_output + "</" + method + ">" + "</soap:Body>" + "</soap:Envelope>";
        }
        System.out.println("TRA Web Service: " + WebServiceTicketRequest_xml);
        return WebServiceTicketRequest_xml;
    }

    private static String invoke_WebService(String WebServiceTicketRequest_xml, String endpoint, String service, String method, ObjectWS Record) throws Exception {
        String WebServiceTicketResponse = null;
        try {
            Service serv = new Service();
            Call call = (Call) serv.createCall();
            String xmlInput = WebServiceTicketRequest_xml;
            byte[] reqBytes = xmlInput.getBytes();
            ByteArrayInputStream bis = new ByteArrayInputStream(reqBytes);
            StreamSource ss = new StreamSource(bis);
            MessageFactoryImpl messageFactory = new MessageFactoryImpl();
            SOAPMessage msg = messageFactory.createMessage();
            SOAPPart soapPart = msg.getSOAPPart();
            soapPart.setContent(ss);
            if ("wsfex".equals(service)) {
                call.setSOAPActionURI("http://ar.gov.afip.dif.fexv/" + method);
            } else if ("wsfe".equals(service)) {
                call.setSOAPActionURI("http://ar.gov.afip.dif.FEV/" + method);
            }
            call.setTargetEndpointAddress(endpoint);
            SOAPEnvelope sOAPEnvelope = call.invoke(((org.apache.axis.SOAPPart) soapPart).getAsSOAPEnvelope());
            WebServiceTicketResponse = sOAPEnvelope.toString();
        } catch (Exception e) {
            Record.seteXmlerror(Boolean.valueOf(true));
            Record.setXml_Output("<resultado>X</resultado><arrayErrores><codigoDescripcion><codigo></codigo><descripcion>" + e.getMessage() + "</descripcion></codigoDescripcion></arrayErrores>");
            e.printStackTrace();
        }
        return WebServiceTicketResponse;
    }
}

 